
Test - v1 2022-05-23 12:37pm
==============================

This dataset was exported via roboflow.ai on May 23, 2022 at 5:37 PM GMT

It includes 154 images.
Archivador are annotated in COCO Segmentation format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


